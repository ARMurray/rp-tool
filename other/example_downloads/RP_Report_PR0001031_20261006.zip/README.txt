RP Report Package
-----------------
Generated:2026-10-06 10:18:58
NPDES Permit ID: PR0001031
----------------------------------
REPORT SETTINGS:
 Dates Queried: 2021-10-06 to 2026-10-06
Hardness: 100