RP Report Package
-----------------
Generated:2026-10-06 10:23:30
NPDES Permit ID: PR0000698
----------------------------------
REPORT SETTINGS:
 Dates Queried: 2018-09-01 to 2026-06-30
Hardness: 100